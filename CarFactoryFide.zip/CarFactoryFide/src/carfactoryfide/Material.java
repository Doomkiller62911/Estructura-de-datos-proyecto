
package carfactoryfide;


public class Material {
    
    private String nombre;

    public Material(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    
}//fin de la clase
