
package carfactoryfide;


public class LineaProduccion {
    
    
   private Material[] materiales;
    private int cantidadMateriales;

    public LineaProduccion() {
        this.materiales = new Material[10]; 
        this.cantidadMateriales = 0;
    }

    public void agregarMaterial(Material material) {
        if (cantidadMateriales < materiales.length) {
            materiales[cantidadMateriales] = material;
            cantidadMateriales++;
        } else {
            System.out.println("No se pueden agregar más materiales a la línea de producción.");
        }
    }

    public void construirAuto() {
    }
    
}//fin de la clase
