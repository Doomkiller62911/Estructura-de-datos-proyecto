
package carfactoryfide;


public class CintaTransportadora {
    
    private Material[] materiales;
    private int capacidadMaxima;
    private int cantidadMateriales;

    public CintaTransportadora(int capacidadMaxima) {
        this.capacidadMaxima = capacidadMaxima;
        this.materiales = new Material[capacidadMaxima];
        this.cantidadMateriales = 0;
    }

    public void agregarMaterial(Material material) {
        if (cantidadMateriales < capacidadMaxima) {
            materiales[cantidadMateriales] = material;
            cantidadMateriales++;
        } else {
            System.out.println("La cinta transportadora está llena.");
        }
    }

    public Material[] getMateriales() {
        return materiales;
    }

    public void generarMateriales() {
    }

    public void reponerMateriales() {
    }

    
}//fin de la clase
