
package carfactoryfide;


public class CarFactoryFide {

    public static void main(String[] args) {
        
        
        
    }//FIN DEL MAIN
    
}//FIN DE LA CLASE
